# خطوات إنشاء الريبو على GitHub (للمالك — هذا الملف لا يُنشر)

## 1) إنشاء الريبو
1. افتح github.com وسجّل دخولك (أو أنشئ حساباً).
2. New repository → الاسم المقترح: `APIBridge`
3. الوصف (Description) المقترح:
   `Local API bridge for ZCode/OpenCode — one local endpoint, same-model failover, smart unified model, automatic quarantine. Local-first: no cloud, no telemetry, keys stay on your machine.`
4. اختر **Public** (عشان النجمة والدعم والظهور) — وقرار النشر قرارك وحدك.
5. لا تفعّل "Add README" — ملفاتنا جاهزة هنا.

## 2) رفع المحتوى
- ارفع كل ملفات هذه الحزمة كما هي (README, PRIVACY, SECURITY, LICENSE,
  CONTRIBUTING, CODE_OF_CONDUCT, CHANGELOG, ROADMAP, .gitignore, .github/).
- أضف سورس المشروع من أحدث source zip (مجلد src/ وbuild.bat وباقي ملفات
  السورس) في جذر الريبو.
- **لا ترفع أبداً**: مجلد `data/` الحقيقي من جهازك (فيه مفاتيحك)، ولا أي
  ملف exe مبني من نسخة فيها بياناتك. ملف `.gitignore` المرفق يمنع ده
  تلقائياً لو استخدمت git.

## 3) إعدادات ما بعد الإنشاء (من Settings في الريبو)
- فعّل **Private vulnerability reporting** (Security → Code security)
  عشان SECURITY.md يشتغل بزرار "Report a vulnerability".
- أضف Topics: `openai-compatible` `local-proxy` `failover` `zcode`
  `opencode` `winforms` `csharp` `ai-tools`
- (اختياري) GitHub Sponsors: بعد تفعيله حدّث `.github/FUNDING.yml`
  باسم مستخدمك، واحذف التعليقات.

## 4) أول Release
- Releases → New release → Tag: `v6.1.13`
- ارفع ملفي الـportable والـsource وملف SHA256SUMS.txt كما نسلّمهم دائماً.
- عنوان الإصدار: `APIBridge v6.1.13`

## ملحوظة الترخيص
الحزمة فيها رخصة **MIT** (الأشهر للمشاريع المشابهة). لو حابب رخصة
مختلفة أو تبقي السورس للعرض فقط بدون إعادة استخدام، قولي وأبدّلها قبل
النشر.
